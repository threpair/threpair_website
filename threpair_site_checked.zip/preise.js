const PRICE_DATA = {
  Apple: {
    "iPhone SE 2020": { display:{original:169, copy:119}, battery:{original:89, copy:89}, backcover:{original:129, copy:109}, chargeport:{original:99, copy:89} },
    "iPhone SE 2022": { display:{original:179, copy:129}, battery:{original:89, copy:89}, backcover:{original:139, copy:119}, chargeport:{original:99, copy:89} },
    "iPhone 11": { display:{original:189, copy:129}, battery:{original:89, copy:89}, backcover:{original:149, copy:119}, chargeport:{original:109, copy:95} },
    "iPhone 11 Pro": { display:{original:239, copy:169}, battery:{original:99, copy:99}, backcover:{original:179, copy:149}, chargeport:{original:119, copy:105} },
    "iPhone 11 Pro Max": { display:{original:259, copy:189}, battery:{original:99, copy:99}, backcover:{original:189, copy:159}, chargeport:{original:119, copy:105} },
    "iPhone 12 mini": { display:{original:239, copy:169}, battery:{original:99, copy:99}, backcover:{original:189, copy:149}, chargeport:{original:119, copy:109} },
    "iPhone 12": { display:{original:249, copy:179}, battery:{original:99, copy:99}, backcover:{original:199, copy:159}, chargeport:{original:119, copy:109} },
    "iPhone 12 Pro": { display:{original:269, copy:189}, battery:{original:109, copy:109}, backcover:{original:209, copy:169}, chargeport:{original:129, copy:119} },
    "iPhone 12 Pro Max": { display:{original:299, copy:219}, battery:{original:109, copy:109}, backcover:{original:229, copy:189}, chargeport:{original:129, copy:119} },
    "iPhone 13 mini": { display:{original:269, copy:199}, battery:{original:109, copy:109}, backcover:{original:209, copy:169}, chargeport:{original:129, copy:119} },
    "iPhone 13": { display:{original:289, copy:209}, battery:{original:109, copy:109}, backcover:{original:219, copy:179}, chargeport:{original:129, copy:119} },
    "iPhone 13 Pro": { display:{original:339, copy:249}, battery:{original:119, copy:119}, backcover:{original:259, copy:209}, chargeport:{original:139, copy:129} },
    "iPhone 13 Pro Max": { display:{original:369, copy:279}, battery:{original:119, copy:119}, backcover:{original:279, copy:229}, chargeport:{original:139, copy:129} },
    "iPhone 14": { display:{original:329, copy:239}, battery:{original:119, copy:119}, backcover:{original:239, copy:189}, chargeport:{original:139, copy:129} },
    "iPhone 14 Plus": { display:{original:359, copy:269}, battery:{original:119, copy:119}, backcover:{original:259, copy:209}, chargeport:{original:149, copy:139} },
    "iPhone 14 Pro": { display:{original:419, copy:319}, battery:{original:129, copy:129}, backcover:{original:309, copy:249}, chargeport:{original:159, copy:149} },
    "iPhone 14 Pro Max": { display:{original:469, copy:349}, battery:{original:129, copy:129}, backcover:{original:339, copy:279}, chargeport:{original:159, copy:149} },
    "iPhone 15": { display:{original:359, copy:269}, battery:{original:129, copy:129}, backcover:{original:259, copy:209}, chargeport:{original:149, copy:139} },
    "iPhone 15 Plus": { display:{original:389, copy:289}, battery:{original:129, copy:129}, backcover:{original:279, copy:229}, chargeport:{original:159, copy:149} },
    "iPhone 15 Pro": { display:{original:469, copy:349}, battery:{original:139, copy:139}, backcover:{original:339, copy:279}, chargeport:{original:169, copy:159} },
    "iPhone 15 Pro Max": { display:{original:519, copy:389}, battery:{original:139, copy:139}, backcover:{original:369, copy:299}, chargeport:{original:169, copy:159} },
    "iPhone 16": { display:{original:389, copy:299}, battery:{original:139, copy:139}, backcover:{original:289, copy:239}, chargeport:{original:159, copy:149} },
    "iPhone 16 Plus": { display:{original:419, copy:319}, battery:{original:139, copy:139}, backcover:{original:309, copy:259}, chargeport:{original:169, copy:159} },
    "iPhone 16 Pro": { display:{original:499, copy:379}, battery:{original:149, copy:149}, backcover:{original:359, copy:299}, chargeport:{original:179, copy:169} },
    "iPhone 16 Pro Max": { display:{original:549, copy:419}, battery:{original:149, copy:149}, backcover:{original:389, copy:329}, chargeport:{original:179, copy:169} }
  },
  Samsung: {
    "Galaxy A13": { display:{original:139, copy:99}, battery:{original:89, copy:89}, chargeport:{original:99, copy:89} },
    "Galaxy A14": { display:{original:149, copy:109}, battery:{original:89, copy:89}, chargeport:{original:99, copy:89} },
    "Galaxy A15": { display:{original:159, copy:119}, battery:{original:89, copy:89}, chargeport:{original:99, copy:89} },
    "Galaxy A23": { display:{original:159, copy:119}, battery:{original:89, copy:89}, chargeport:{original:99, copy:89} },
    "Galaxy A24": { display:{original:169, copy:129}, battery:{original:89, copy:89}, chargeport:{original:99, copy:89} },
    "Galaxy A33": { display:{original:169, copy:129}, battery:{original:89, copy:89}, chargeport:{original:109, copy:95} },
    "Galaxy A34": { display:{original:179, copy:139}, battery:{original:89, copy:89}, chargeport:{original:109, copy:95} },
    "Galaxy A35": { display:{original:189, copy:149}, battery:{original:95, copy:95}, chargeport:{original:109, copy:99} },
    "Galaxy A52": { display:{original:189, copy:149}, battery:{original:89, copy:89}, chargeport:{original:109, copy:95} },
    "Galaxy A53": { display:{original:199, copy:159}, battery:{original:89, copy:89}, chargeport:{original:109, copy:95} },
    "Galaxy A54": { display:{original:219, copy:169}, battery:{original:95, copy:95}, chargeport:{original:119, copy:99} },
    "Galaxy A55": { display:{original:239, copy:189}, battery:{original:99, copy:99}, chargeport:{original:119, copy:105} },
    "Galaxy S20": { display:{original:249, copy:199}, battery:{original:99, copy:99}, backcover:{original:159, copy:129}, chargeport:{original:129, copy:119} },
    "Galaxy S20 FE": { display:{original:219, copy:169}, battery:{original:99, copy:99}, backcover:{original:149, copy:119}, chargeport:{original:119, copy:109} },
    "Galaxy S21": { display:{original:269, copy:209}, battery:{original:99, copy:99}, backcover:{original:169, copy:139}, chargeport:{original:129, copy:119} },
    "Galaxy S21 FE": { display:{original:249, copy:189}, battery:{original:99, copy:99}, backcover:{original:159, copy:129}, chargeport:{original:129, copy:119} },
    "Galaxy S22": { display:{original:299, copy:229}, battery:{original:109, copy:109}, backcover:{original:179, copy:149}, chargeport:{original:139, copy:129} },
    "Galaxy S23": { display:{original:329, copy:249}, battery:{original:109, copy:109}, backcover:{original:189, copy:159}, chargeport:{original:149, copy:139} },
    "Galaxy S23 FE": { display:{original:299, copy:229}, battery:{original:109, copy:109}, backcover:{original:179, copy:149}, chargeport:{original:149, copy:139} },
    "Galaxy S24": { display:{original:359, copy:279}, battery:{original:119, copy:119}, backcover:{original:199, copy:169}, chargeport:{original:159, copy:149} },
    "Galaxy S24 FE": { display:{original:329, copy:249}, battery:{original:119, copy:119}, backcover:{original:189, copy:159}, chargeport:{original:159, copy:149} }
  }
};

const REPAIR_LABELS = {
  display: "Display",
  battery: "Akku",
  backcover: "Backcover",
  chargeport: "Ladebuchse"
};

const PART_INFO = {
  display_original: {
    title: "Original-Display",
    text: "Original-Ersatzteile sind teurer, bieten dafür die beste Passform, Farbdarstellung und Haptik. Bei Apple lassen sich Original-Displays je nach Modell ab iOS 18 wieder kalibrieren."
  },
  display_copy: {
    title: "Soft OLED / hochwertiger Nachbau",
    text: "Hochwertige Nachbau-Displays wie Soft OLED sind eine preisgünstigere Alternative. Die Nutzung wird nicht beeinträchtigt, jedoch können Farben, Helligkeit oder das Touchgefühl leicht vom Original abweichen. Teilweise kann ein Hinweis erscheinen, dass kein Original-Produkt verbaut ist."
  },
  battery_original: {
    title: "Original-Akku",
    text: "Original-Akkus sind die hochwertigste Lösung. Garantie auf Akkus beträgt immer 3 Monate."
  },
  battery_copy: {
    title: "Akku mit TI-Chip / hochwertiger Nachbau",
    text: "Sehr hochwertige Nachbau-Akkus mit TI-Chip sind eine gute Alternative. Garantie auf Akkus beträgt immer 3 Monate."
  }
};
